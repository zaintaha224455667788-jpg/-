# تشغيل سريع على هاتف Android

- افتح `index.html` في متصفح حديث لتجربة نموذج قابل للعب دون تثبيت تطبيق.
- هذه نسخة HTML5 خفيفة للتحكم باللمس وليست APK.
- مشروع Godot ثلاثي الأبعاد الأصلي موجود في `project.godot` و`Main.tscn` و`scripts/main.gd`.
- لبناء APK أصلي، افتح مشروع Godot على كمبيوتر وثبّت Android export templates وAndroid SDK ثم صدّره من Project > Export.
