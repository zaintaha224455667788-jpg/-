extends Node3D

# نجوم الملعب: نموذج أولي قابل للتوسعة. حركة بسيطة، تمرير/تسديد، وواجهة لمس.
const FIELD_W := 22.0
const FIELD_L := 34.0
const PLAYER_SPEED := 7.0
const KICK_SPEED := 16.0

var player: CharacterBody3D
var opponent: Node3D
var ball: RigidBody3D
var score_home := 0
var score_away := 0
var move_dir := Vector2.ZERO
var shoot_requested := false
var pass_requested := false
var score_label: Label
var message_label: Label
var buttons := {}

func _ready() -> void:
    _make_environment()
    _make_field()
    _make_player()
    _make_opponent()
    _make_ball()
    _make_goals()
    _make_camera()
    _make_ui()
    _update_score()

func _make_environment() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.18, 0.35, 0.52)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.75, 0.82, 0.9)
    env.ambient_light_energy = 0.8
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)

func _mat(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.9
    return m

func _box(parent: Node3D, name: String, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = name
    var mesh := BoxMesh.new()
    mesh.size = size
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color)
    parent.add_child(node)
    return node

func _make_field() -> void:
    _box(self, "Grass", Vector3(FIELD_W, 0.2, FIELD_L), Vector3(0, -0.15, 0), Color(0.12, 0.48, 0.2))
    # خطوط الملعب
    _box(self, "CenterLine", Vector3(FIELD_W, 0.025, 0.08), Vector3(0, -0.035, 0), Color.WHITE)
    var circle := MeshInstance3D.new()
    var ring := TorusMesh.new()
    ring.inner_radius = 3.7
    ring.outer_radius = 3.82
    circle.mesh = ring
    circle.position.y = -0.025
    circle.material_override = _mat(Color.WHITE)
    add_child(circle)
    for z in [-FIELD_L / 2.0 + 4.0, FIELD_L / 2.0 - 4.0]:
        _box(self, "PenaltyLine", Vector3(10, 0.025, 0.08), Vector3(0, -0.03, z), Color.WHITE)
        _box(self, "PenaltySideA", Vector3(0.08, 0.025, 4), Vector3(-5, -0.03, z + (2 if z < 0 else -2)), Color.WHITE)
        _box(self, "PenaltySideB", Vector3(0.08, 0.025, 4), Vector3(5, -0.03, z + (2 if z < 0 else -2)), Color.WHITE)
    # خطوط جانبية
    for x in [-FIELD_W/2.0, FIELD_W/2.0]:
        _box(self, "TouchLine", Vector3(0.07, 0.025, FIELD_L), Vector3(x, -0.03, 0), Color.WHITE)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.name = "BlueTeamPlayer"
    player.position = Vector3(0, 0.05, 8)
    add_child(player)
    _build_person(player, Color(0.08, 0.32, 0.95), Color(0.95, 0.95, 1.0))
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.42
    shape.height = 1.8
    collision.shape = shape
    collision.position.y = 0.9
    player.add_child(collision)

func _make_opponent() -> void:
    opponent = Node3D.new()
    opponent.name = "RedTeamPlayer"
    opponent.position = Vector3(2, 0.05, -3)
    add_child(opponent)
    _build_person(opponent, Color(0.85, 0.08, 0.12), Color(0.95, 0.85, 0.72))

func _build_person(parent: Node3D, shirt: Color, skin: Color) -> void:
    var body := MeshInstance3D.new()
    var body_mesh := CapsuleMesh.new()
    body_mesh.radius = 0.38
    body_mesh.height = 1.15
    body.mesh = body_mesh
    body.position.y = 1.05
    body.material_override = _mat(shirt)
    parent.add_child(body)
    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.23
    head_mesh.height = 0.46
    head.mesh = head_mesh
    head.position.y = 1.82
    head.material_override = _mat(skin)
    parent.add_child(head)
    for side in [-1.0, 1.0]:
        var leg := MeshInstance3D.new()
        var leg_mesh := CapsuleMesh.new()
        leg_mesh.radius = 0.13
        leg_mesh.height = 0.75
        leg.mesh = leg_mesh
        leg.position = Vector3(side * 0.2, 0.38, 0)
        leg.material_override = _mat(Color(0.08, 0.1, 0.16))
        parent.add_child(leg)

func _make_ball() -> void:
    ball = RigidBody3D.new()
    ball.name = "Football"
    ball.position = Vector3(0.5, 0.45, 5.5)
    ball.mass = 0.45
    ball.linear_damp = 0.35
    ball.angular_damp = 0.4
    ball.gravity_scale = 1.0
    add_child(ball)
    var mesh_node := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.32
    sphere.height = 0.64
    mesh_node.mesh = sphere
    mesh_node.material_override = _mat(Color(0.98, 0.98, 0.92))
    ball.add_child(mesh_node)
    var collision := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.32
    collision.shape = shape
    ball.add_child(collision)

func _make_goals() -> void:
    for z in [-FIELD_L/2.0 + 0.6, FIELD_L/2.0 - 0.6]:
        var goal := Node3D.new()
        goal.position = Vector3(0, 0, z)
        add_child(goal)
        var sign := 1.0 if z < 0 else -1.0
        for x in [-3.0, 3.0]:
            _box(goal, "GoalPost", Vector3(0.18, 2.3, 0.18), Vector3(x, 1.15, 0), Color.WHITE)
        _box(goal, "GoalCrossbar", Vector3(6.15, 0.18, 0.18), Vector3(0, 2.3, 0), Color.WHITE)
        _box(goal, "GoalNetHint", Vector3(5.8, 1.9, 0.06), Vector3(0, 1.0, -sign * 0.4), Color(0.75, 0.85, 0.9, 0.5))

func _make_camera() -> void:
    var cam := Camera3D.new()
    cam.name = "GameCamera"
    cam.position = Vector3(0, 18, 25)
    cam.rotation_degrees = Vector3(-34, 0, 0)
    cam.current = true
    add_child(cam)

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(20, 18)
    panel.custom_minimum_size = Vector2(260, 60)
    layer.add_child(panel)
    score_label = Label.new()
    score_label.add_theme_font_size_override("font_size", 28)
    score_label.text = "نجوم الملعب  |  0 - 0"
    panel.add_child(score_label)

    message_label = Label.new()
    message_label.position = Vector2(20, 88)
    message_label.add_theme_font_size_override("font_size", 20)
    message_label.text = "حرّك اللاعب وسدّد نحو المرمى"
    layer.add_child(message_label)

    _add_hold_button(layer, "▲", Vector2(100, -190), "up")
    _add_hold_button(layer, "▼", Vector2(100, -80), "down")
    _add_hold_button(layer, "◀", Vector2(35, -135), "left")
    _add_hold_button(layer, "▶", Vector2(165, -135), "right")
    _add_action_button(layer, "تسديد", Vector2(-190, -120), "shoot")
    _add_action_button(layer, "تمرير", Vector2(-190, -45), "pass")

func _add_hold_button(layer: CanvasLayer, label_text: String, offset: Vector2, action: String) -> void:
    var b := Button.new()
    b.text = label_text
    b.custom_minimum_size = Vector2(58, 58)
    b.anchor_left = 0
    b.anchor_top = 1
    b.anchor_right = 0
    b.anchor_bottom = 1
    b.position = offset
    b.add_theme_font_size_override("font_size", 25)
    layer.add_child(b)
    buttons[action] = false
    b.button_down.connect(func(): buttons[action] = true)
    b.button_up.connect(func(): buttons[action] = false)

func _add_action_button(layer: CanvasLayer, label_text: String, offset: Vector2, action: String) -> void:
    var b := Button.new()
    b.text = label_text
    b.custom_minimum_size = Vector2(110, 58)
    b.anchor_left = 1
    b.anchor_top = 1
    b.anchor_right = 1
    b.anchor_bottom = 1
    b.position = offset
    b.add_theme_font_size_override("font_size", 19)
    layer.add_child(b)
    b.pressed.connect(func():
        if action == "shoot":
            shoot_requested = true
        else:
            pass_requested = true
    )

func _physics_process(delta: float) -> void:
    var input_vec := Vector2.ZERO
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) or buttons.get("up", false):
        input_vec.y -= 1
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN) or buttons.get("down", false):
        input_vec.y += 1
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or buttons.get("left", false):
        input_vec.x -= 1
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or buttons.get("right", false):
        input_vec.x += 1
    if input_vec.length() > 1:
        input_vec = input_vec.normalized()
    player.velocity.x = input_vec.x * PLAYER_SPEED
    player.velocity.z = input_vec.y * PLAYER_SPEED
    player.velocity.y = 0
    player.move_and_slide()
    player.position.x = clamp(player.position.x, -FIELD_W/2.0 + 1, FIELD_W/2.0 - 1)
    player.position.z = clamp(player.position.z, -FIELD_L/2.0 + 1, FIELD_L/2.0 - 1)

    # اقتراب الكرة من اللاعب يجعلها قابلة للسيطرة والدفع
    var distance := player.global_position.distance_to(ball.global_position)
    if distance < 1.6 and input_vec.length() > 0.1:
        var push := Vector3(input_vec.x, 0, input_vec.y).normalized()
        ball.apply_central_force(push * 5.5)
    if shoot_requested:
        _kick_ball(KICK_SPEED)
        shoot_requested = false
    if pass_requested:
        _kick_ball(8.0)
        pass_requested = false

    # خصم تجريبي يتحرك نحو الكرة
    var target := Vector3(ball.position.x, 0.05, ball.position.z)
    var to_ball := target - opponent.position
    to_ball.y = 0
    if to_ball.length() > 1.0:
        opponent.position += to_ball.normalized() * delta * 2.2

    # إبقاء الكرة داخل حدود الملعب تقريبًا
    if abs(ball.position.x) > FIELD_W/2.0:
        ball.linear_velocity.x *= -0.65
        ball.position.x = clamp(ball.position.x, -FIELD_W/2.0, FIELD_W/2.0)
    if abs(ball.position.z) > FIELD_L/2.0:
        _check_goal()
        ball.linear_velocity.z *= -0.55
        ball.position.z = clamp(ball.position.z, -FIELD_L/2.0, FIELD_L/2.0)

func _kick_ball(power: float) -> void:
    var distance := player.global_position.distance_to(ball.global_position)
    if distance > 3.0:
        message_label.text = "اقترب من الكرة أولاً!"
        return
    var direction := Vector3(0, 0, -1)
    if player.velocity.length() > 0.5:
        direction = Vector3(player.velocity.x, 0, player.velocity.z).normalized()
    direction.y = 0.12 if power > 10 else 0.04
    ball.apply_central_impulse(direction.normalized() * power)
    message_label.text = "تسديدة قوية!" if power > 10 else "تمريرة!"

func _check_goal() -> void:
    if abs(ball.position.x) <= 3.1:
        if ball.position.z < 0:
            score_home += 1
            message_label.text = "هدف لفريقك! ⚽"
        else:
            score_away += 1
            message_label.text = "هدف للفريق المنافس"
        _update_score()
        ball.linear_velocity = Vector3.ZERO
        ball.angular_velocity = Vector3.ZERO
        ball.position = Vector3(0.5, 0.45, 5.5)
        player.position = Vector3(0, 0.05, 8)

func _update_score() -> void:
    if is_instance_valid(score_label):
        score_label.text = "نجوم الملعب  |  %d - %d" % [score_home, score_away]
